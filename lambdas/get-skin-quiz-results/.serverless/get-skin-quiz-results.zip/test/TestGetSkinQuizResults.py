import unittest
import src.GetSkinQuizResults as GetSkinQuizResults
import json


class TestGetSkinQuizResults(unittest.TestCase):
    def test_lambda_handler_empty_response(self):
        self.assertEqual(
            GetSkinQuizResults.lambda_handler({}, {}),
            {'body': 'Empty or no "body" parameter in request.', 'statusCode': 400}
        )

    def test_lambda_handler_empty_body(self):
        self.assertEqual(
            GetSkinQuizResults.lambda_handler({'body': {}}, {}),
            {'body': 'Empty or no "body" parameter in request.', 'statusCode': 400}
        )

    def test_lambda_handler_bad_json_body(self):
        self.assertEqual(
            GetSkinQuizResults.lambda_handler({'body': "crap"}, {}),
            {'body': 'Unable to parse JSON in "body" parameter in request.',
                'statusCode': 400}
        )

    def test_lambda_handler_body_no_quiz_answers(self):
        json_body = json.dumps({'test_key': 'test_value'})
        self.assertEqual(
            GetSkinQuizResults.lambda_handler({'body': json_body}, {}),
            {'body': 'No "quiz_answers" parameter in "body" request.', 'statusCode': 400}
        )

    def test_lambda_handler_body_1_quiz_answers(self):
        json_body = json.dumps({'quiz_answers': ['acne']})
        self.assertEqual(
            GetSkinQuizResults.lambda_handler({'body': json_body}, {}),
            {
                'statusCode': 200,
                'body': {
                    'quiz_results':
                        [('acne', 'lalala')]
                }
            }
        )


if __name__ == '__main__':
    unittest.main()
